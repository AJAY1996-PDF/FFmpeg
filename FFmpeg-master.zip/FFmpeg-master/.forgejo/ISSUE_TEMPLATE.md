# Summary of the bug

Briefly describe the issue you're experiencing. Include any error messages, unexpected behavior, or relevant observations.

# Steps to reproduce

List the steps required to trigger the bug.
Include the exact CLI command used, if any.
Provide sample input files, logs, or scripts if available.
