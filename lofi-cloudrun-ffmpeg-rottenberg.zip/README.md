# Cloud Run FFmpeg API (Option 3: rottenberg/ffmpeg base)

This template uses **jrottenberg/ffmpeg** Docker image to provide a full, fast ffmpeg inside Cloud Run.
It exposes three endpoints for n8n:

- `POST /jobs` → create a render job (merge `video_url` + `audio_url`, optional `cover_url`)
- `GET /jobs/:id/status` → `{ status }`
- `GET /jobs/:id/result` → `{ output_url }`

## Deploy (Console, ZIP upload)

1. Zip this folder.
2. Cloud Run → Create Service → *Deploy from source* → Upload ZIP.
3. Build uses Dockerfile automatically (Cloud Build).
4. Allow unauthenticated invocations.
5. Copy the service URL.

## Deploy (CLI)

```bash
gcloud run deploy lofi-cloudrun-ffmpeg \
  --source . \
  --region asia-east1 \
  --allow-unauthenticated
```

## Request body example

```json
{
  "inputs": {
    "audio_url": "https://.../bgm.mp3",
    "video_url": "https://.../loop.mp4",
    "cover_url": "https://.../cover.png"
  },
  "mix": { "volume": 0.85, "fadeIn": 2.0, "fadeOut": 2.0 },
  "render": { "fps": 30, "crf": 20, "resolution": "1080x1920" }
}
```

## Google Drive upload (optional)

- Set env var `DRIVE_UPLOAD=true`.
- Ensure the Cloud Run service account has access to a Drive folder (share a folder to the service account email).
- The code will upload `/tmp/.../output.mp4` to Drive and return `webViewLink`.

## Notes

- `/tmp` is writeable in Cloud Run. Each request runs inside an instance, so don't rely on persistence.
- For production, replace the in-memory job map with Redis/Datastore/Firestore.
