import express from "express";
import { nanoid } from "nanoid";
import { execFile } from "child_process";
import fs from "fs";
import fetch from "node-fetch";
import path from "path";
import { google } from "googleapis";

const app = express();
app.use(express.json({ limit: "50mb" }));

// In-memory store for demo; replace with Redis/DB in production
const jobs = new Map();

async function dl(url, toPath) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Download failed ${res.status} ${url}`);
  await fs.promises.writeFile(toPath, Buffer.from(await res.arrayBuffer()));
  return toPath;
}

function runFFmpeg(args) {
  return new Promise((resolve, reject) => {
    const p = execFile("ffmpeg", args, { maxBuffer: 1024 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) return reject(new Error(stderr || String(err)));
      resolve(stdout || "ok");
    });
  });
}

async function processJob(id, payload) {
  const workdir = `/tmp/job_${id}`;
  await fs.promises.mkdir(workdir, { recursive: true });
  const { inputs = {}, mix = {}, render = {} } = payload;
  const audioUrl = inputs.audio_url;
  const videoUrl = inputs.video_url;
  const coverUrl = inputs.cover_url;

  const audioPath = await dl(audioUrl, path.join(workdir, "audio.mp3"));
  const videoPath = await dl(videoUrl, path.join(workdir, "video.mp4"));
  let coverPath = null;
  if (coverUrl) coverPath = await dl(coverUrl, path.join(workdir, "cover.png"));

  const outPath = path.join(workdir, "output.mp4");

  // Compose filters
  const volume = typeof mix.volume === "number" ? mix.volume : 0.85;
  const fadeIn = typeof mix.fadeIn === "number" ? mix.fadeIn : 2.0;
  const fadeOut = typeof mix.fadeOut === "number" ? mix.fadeOut : 2.0;
  const afilter = `volume=${volume},afade=t=in:ss=0:d=${fadeIn},afade=t=out:st=5:d=${fadeOut}`;

  const fps = render.fps || 30;
  const crf = render.crf || 20;
  const resolution = render.resolution || "1080x1920";

  // Build ffmpeg args
  const args = [
    "-y",
    "-i", videoPath,
    "-i", audioPath,
    ...(coverPath ? ["-loop", "1", "-i", coverPath] : []),
    "-filter:a", afilter,
    "-r", String(fps),
    "-s", resolution,
    "-c:v", "libx264",
    "-preset", "veryfast",
    "-crf", String(crf),
    "-c:a", "aac",
    "-shortest",
    outPath
  ];

  await runFFmpeg(args);

  let outputUrl = null;
  if (process.env.DRIVE_UPLOAD === "true") {
    const link = await uploadToDrive(outPath, `render_${id}.mp4`);
    outputUrl = link;
  } else if (process.env.DEMO_OUTPUT_URL) {
    outputUrl = process.env.DEMO_OUTPUT_URL;
  } else {
    outputUrl = `file://${outPath}`; // local path (for debugging); not public
  }
  return { outputUrl, outPath };
}

// Optional Google Drive upload
async function uploadToDrive(localPath, name) {
  const auth = new google.auth.GoogleAuth({
    scopes: ["https://www.googleapis.com/auth/drive.file"],
  });
  const drive = google.drive({ version: "v3", auth });
  const res = await drive.files.create({
    requestBody: { name },
    media: { body: fs.createReadStream(localPath) },
    fields: "id, webViewLink",
  });
  // Make it readable by anyone with the link (optional)
  try {
    await drive.permissions.create({
      fileId: res.data.id,
      requestBody: { role: "reader", type: "anyone" },
    });
  } catch (_) {}
  return res.data.webViewLink;
}

// Routes
app.post("/jobs", async (req, res) => {
  const id = nanoid();
  jobs.set(id, { status: "queued", created_at: Date.now(), output_url: null, error: null });
  const payload = req.body || {};
  (async () => {
    try {
      jobs.set(id, { ...jobs.get(id), status: "processing" });
      const { outputUrl } = await processJob(id, payload);
      jobs.set(id, { ...jobs.get(id), status: "succeeded", output_url: outputUrl });
    } catch (e) {
      jobs.set(id, { ...jobs.get(id), status: "failed", error: String(e) });
    }
  })();
  res.json({ job_id: id });
});

app.get("/jobs/:id/status", (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: "Job not found" });
  res.json({ status: job.status, error: job.error });
});

app.get("/jobs/:id/result", (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: "Job not found" });
  if (job.status !== "succeeded") return res.status(409).json({ error: "Not ready", status: job.status });
  res.json({ output_url: job.output_url });
});

app.get("/", (req, res) => res.json({ ok: true, service: "lofi-cloudrun-ffmpeg" }));

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Server listening on :${port}`));
